data class Potato(val id: Int, val calories: Int)
