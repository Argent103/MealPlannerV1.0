package com.example.mealplan

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import okhttp3.*
import java.io.IOException

data class Food(
    val description: String,
    val fdcId: Int,
    val foodNutrients: List<FoodNutrient>?
)

data class FoodNutrient(
    val nutrientName: String,
    val unitName: String,
    val value: Double
)
class MealPlan1 : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var nextButton: Button
    private lateinit var prevButton: Button

    private var currentIndex: Int = 0
    private lateinit var foodList: Array<Food>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_plan1)

        listView = findViewById(R.id.list_view)
        nextButton = findViewById(R.id.next_button)
        prevButton = findViewById(R.id.prev_button)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        listView.adapter = adapter

        val client = OkHttpClient()
        val apiKey = "huxfqNv3tv0PW1v7cDaEvK0Z3leFeDNesrYaWwqG"
        val baseUrl = "https://api.nal.usda.gov/fdc/v1"
        val foodUrl = "/foods/list"

        val request = Request.Builder()
            .url("$baseUrl$foodUrl?api_key=$apiKey")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Handle API call failure
                // You can implement error handling logic here
            }

            override fun onResponse(call: Call, response: Response) {
                val responseData = response.body?.string()
                val gson = Gson()
                foodList = gson.fromJson(responseData, Array<Food>::class.java)

                runOnUiThread {
                    showFoodItems()
                    setButtonVisibility()
                }
            }
        })

        nextButton.setOnClickListener {
            currentIndex++
            showFoodItems()
            setButtonVisibility()
        }

        prevButton.setOnClickListener {
            currentIndex--
            showFoodItems()
            setButtonVisibility()
        }
    }

    private fun showFoodItems() {
        adapter.clear()
        val startIndex = currentIndex * 10
        val endIndex = (currentIndex + 1) * 10
        for (i in startIndex until endIndex) {
            val food = foodList.getOrNull(i)
            val item = if (food != null) {
                if (food.foodNutrients != null) {
                    val calories = getCalories(food)
                    "${food.description}, " + "Calories: $calories"


                } else {
                    "No nutrient information available for this food"
                }
            } else {
                "No food item available"
            }
            adapter.add(item)
        }
        adapter.notifyDataSetChanged()
    }


    private fun setButtonVisibility() {
        nextButton.visibility = if ((currentIndex + 1) * 10 < foodList.size) {
            View.VISIBLE
        } else {
            View.INVISIBLE
        }

        prevButton.visibility = if (currentIndex > 0) {
            View.VISIBLE
        } else {
            View.INVISIBLE
        }
    }

    private fun getCalories(food: Food): Double {
        val nutrients = food.foodNutrients
        val caloriesNutrient = nutrients?.find { it.nutrientName == "Energy" && it.unitName == "kcal" }
        return caloriesNutrient?.value ?: 0.0
    }

}
