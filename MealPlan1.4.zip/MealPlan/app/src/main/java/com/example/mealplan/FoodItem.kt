package com.example.mealplan

data class FoodItem(val name: String, val calories: Double)